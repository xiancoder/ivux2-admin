module.exports = function(app) {
    app.post('/api/system/staff_login', (req, res) => {
        const json = {
            'code': 200,
            'msg': '',
            'data': {'res': 1, 'userId': 1}
        }
        res.json(json)
    })
    app.get('/api/qun/realtime_list', (req, res) => {
        const json = {
            'code': 200,
            'msg': '',
            'data': {
                'list': [
                    {'id': 34, 'crowdName': '测试三', 'online': 9, 'crowdCount': 200, 'overDay': 2},
                    {'id': 35, 'crowdName': '知识的力量', 'online': 0, 'crowdCount': 190, 'overDay': 3},
                    {'id': 36, 'crowdName': '测试2020', 'online': 0, 'crowdCount': 200, 'overDay': 3},
                    {'id': 37, 'crowdName': '特事特办群', 'online': 0, 'crowdCount': 200, 'overDay': 3},
                    {'id': 38, 'crowdName': '测试7', 'online': 0, 'crowdCount': 200, 'overDay': 3},
                    {'id': 39, 'crowdName': '电脑加一个', 'online': 0, 'crowdCount': 200, 'overDay': 3},
                    {'id': 40, 'crowdName': '蜜柚小站', 'online': 0, 'crowdCount': 200, 'overDay': 5}
                ],
                'rowcount': 7
            }
        }
        res.json(json)
    })
    app.get('/api/qun/total', (req, res) => {
        const json = {
            'code': 200,
            'msg': '',
            'data': {'groupTotal': 13, 'userTotal': 20, 'fullTotal': 61}
        }
        res.json(json)
    })
    app.get('/api/qun/getInfo', (req, res) => {
        const json = {
            'code': 200,
            'msg': '',
            'data': {
                'info': {
                    'id': 34,
                    'name': '测试三',
                    'maxCount': 200,
                    'qrcodeImg': 'https://p2.ssl.qhimgs1.com/sdr/400__/t01918ffdc29952da42.gif'
                }
            }
        }
        res.json(json)
    })
    app.post('/api/imgFile/upload', (req, res) => {
        const json = {
            'code': 200,
            'msg': '',
            'data': {
                'res': 1,
                'path': 'https://p2.ssl.qhimgs1.com/sdr/400__/t01918ffdc29952da42.gif'
            }
        }
        res.json(json)
    })
    app.post('/api/qun/create', (req, res) => {
        const json = {
            'code': 200,
            'msg': '',
            'data': {
                'res': 1
            }
        }
        res.json(json)
    })
    app.get('/api/qun/delete', (req, res) => {
        const json = {
            'code': 200,
            'msg': '',
            'data': {
                'res': 1
            }
        }
        res.json(json)
    })
}

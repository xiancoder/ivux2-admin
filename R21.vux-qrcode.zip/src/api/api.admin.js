import axios from 'axios' // http请求库
import { success, error } from '@/tools' // 自定义常用工具

export default {
    sLogin ({ // 导入 上传封账数据
        companyId, // 公司ID
        file // 改成的状态
    }) {
        let fd = new FormData()
        fd.append('company_id', companyId || 1)
        fd.append('file', file);
        return new Promise((resolve, reject) => {
            axios({
                method: 'POST',
                url: '/api/cost/upload_real_cost',
                data: fd,
                headers: { 'Content-Type': 'multipart/form-data' },
                timeout: 300000
            }).then(response => { // 请注意这个返回值是整个结果对象
                const res = response.data
                if (res && res.data && res.data.res_code) {
                    success(res.data.res || '导入成功') // 报错并继续reject
                    resolve()
                } else {
                    error(res.data.res) // 报错并继续reject
                    reject(res.data.res)
                }
            }).catch(e => {
                error(e.message) // ajax异常后 报错并中止操作
            })
        })
    },
    end () {} // 错误占位符
}

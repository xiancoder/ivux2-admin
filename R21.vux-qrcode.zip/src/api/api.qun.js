import axios from 'axios' // http请求库
import { success, error } from '@/tools' // 自定义常用工具

export default {
    totalInfo () {
        return new Promise((resolve, reject) => {
            axios.get('/api/qun/total').then(response => { // 请注意这个返回值是整个结果对象
                const res = response.data
                if (res && res.data) {
                    resolve(res.data)
                } else {
                    error(res.data.res) // 报错并继续
                    resolve({'groupTotal': 0, 'userTotal': 0, 'fullTotal': 0})
                }
            }).catch(e => {
                error(e.message) // ajax异常后 报错并中止操作
            })
        })
    },
    del (id) {
        return new Promise((resolve, reject) => {
            axios.get('/api/qun/delete', {id}).then(response => { // 请注意这个返回值是整个结果对象
                const res = response.data
                if (res && res.data && res.data === 1) {
                    success()
                    resolve(res.data)
                } else {
                    error(res.data.res) // 报错并继续
                    reject()
                }
            }).catch(e => {
                error(e.message) // ajax异常后 报错并中止操作
            })
        })
    },
    realtimeList (page) {
        return new Promise((resolve, reject) => {
            axios.get('/api/qun/realtime_list', {
                type: 1,
                pageIndex: page,
                pageSize: 15
            }).then(response => { // 请注意这个返回值是整个结果对象
                const res = response.data
                if (res && res.data) {
                    resolve(res.data)
                } else {
                    error('读取数据失败') // 报错并继续
                    reject()
                }
            }).catch(e => {
                error(e.message) // ajax异常后 报错并中止操作
            })
        })
    },
    end () {} // 错误占位符
}

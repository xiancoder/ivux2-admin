<template>
    <div style="color: #9a9a9a;margin-top: 100px;text-align: center;">
        <p> 暂无数据</p>
    </div>
</template>
<script>
export default {
    // dsf-2020-02-20
    name: 'no-data'
}
</script>

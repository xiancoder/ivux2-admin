global.loginType = 2;

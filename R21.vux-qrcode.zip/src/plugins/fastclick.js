import FastClick from 'fastclick'

FastClick.attach(document.body)

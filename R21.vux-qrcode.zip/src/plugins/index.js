import './vux' // Ui
import './fastclick' // 快速点击
import 'font-awesome/css/font-awesome.min.css' // 优美字体
import './vconsole' // 移动端调试

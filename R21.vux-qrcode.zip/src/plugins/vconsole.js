import VConsole from 'vconsole/dist/vconsole.min.js' // 移动端调试

new VConsole()

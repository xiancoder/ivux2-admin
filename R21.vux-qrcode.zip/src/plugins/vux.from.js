import Vue from 'vue'
import {
    XInput, Group
} from 'vux'

Vue.component('x-input', XInput)
Vue.component('group', Group)

import Vue from 'vue'
import {
    ToastPlugin, AlertPlugin, LoadingPlugin, ConfirmPlugin,
    XHeader, XButton, Divider
} from 'vux'

Vue.use(ToastPlugin)
Vue.use(AlertPlugin)
Vue.use(LoadingPlugin)
Vue.use(ConfirmPlugin)

Vue.component('x-header', XHeader)
Vue.component('x-button', XButton)
Vue.component('divider', Divider)
console.log('仙', '全局注册vux组件')

import Vue from 'vue'
import {
    XTable, Scroller, LoadMore
} from 'vux'

Vue.component('x-table', XTable)
Vue.component('scroller', Scroller)
Vue.component('load-more', LoadMore)

import Vue from 'vue'
import VueRouter from 'vue-router'
import {routers} from './router';

Vue.use(VueRouter);

// 路由配置
const RouterConfig = {
    routes: routers,
    // mode: 'hash'
    mode: 'history'
};

export const router = new VueRouter(RouterConfig);

router.beforeEach((to, from, next) => {
    if (window.localStorage.getItem('imlogined') && to.name === 'sLogin') {
        return next({ name: 'home-realTimeQun' });
    }
    next() // 进入页面
});
router.afterEach((to) => {
    window.scrollTo(0, 0);
});

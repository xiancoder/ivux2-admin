import Main from '@/views/Main.vue'
import Exp from '@/views/Exp.vue'

export const shareRouter = [
    // 分享-登录
    { path: '/login', name: 'login', component: () => import('@/views/other/login.vue') },
    // 分享-回调
    { path: '/recall', name: 'recall', component: () => import('@/views/other/invite.vue') },
    // 分享-分享
    { path: '/share', name: 'share', component: () => import('@/views/other/share.vue') }
]

export const mainRouter = {
    path: '/', name: 'main', redirect: '/sLogin', component: Main,
    children: [
        // 后台-登录页
        { path: 'sLogin', name: 'home-sLogin', component: () => import('@/views/sLogin.vue') },
        // 后台-实时数据
        { path: 'realTimeQun', name: 'home-realTimeQun', component: () => import('@/views/home/realTimeQun.vue') },
        // 后台-生成推广码
        { path: 'code-create', name: 'code-create', component: () => import('@/views/home/code-create.vue') },
        // 后台-已满群
        { path: 'gratifiedQun', name: 'home-gratifiedQun', component: () => import('@/views/home/gratifiedQun.vue') },
        // 后台-新增/编辑 扩展群
        { path: 'editQun', name: 'home-editQun', component: () => import('@/views/home/editQun.vue') },
        // 后台-数据查询
        { path: 'list', name: 'list', component: () => import('@/views/home/list.vue') },
        // 后台-测试页
        { path: 'test', name: 'test', component: () => import('@/views/test/test.vue') }
    ]
}

export const expRouter = {
    path: '/exp/', name: 'exp', redirect: '/exp/list', component: Exp,
    children: [
        // 列表
        { path: 'list', name: 'exp-list', component: () => import('@/views/exp/index.vue') },
        { path: 'exp01', name: 'exp-01', component: () => import('@/views/exp/exp01.vue') },
        { path: 'exp01auto', name: 'exp-01auto', component: () => import('@/views/exp/exp01auto.vue') },
        { path: 'exp01heng', name: 'exp-01heng', component: () => import('@/views/exp/exp01heng.vue') },
        { path: 'exp02', name: 'exp-02', component: () => import('@/views/exp/exp02.vue') },
        { path: 'exp03', name: 'exp-03', component: () => import('@/views/exp/exp03.vue') }
    ]
}

export const routers = [
    mainRouter,
    ...shareRouter,
    expRouter
]

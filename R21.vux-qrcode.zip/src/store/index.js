import Vue from 'vue' // 核心
import Vuex from 'vuex'
import createPersistedState from 'vuex-persistedstate' // 状态持久化

import admin from './store.admin' // 管理员/用户相关

Vue.use(Vuex)

const plugins = [
    createPersistedState({ // 状态持久化
        storage: window.localStorage,
        reducer: (store) => {
            const {token} = store.admin
            return { // 只储存指定的状态
                admin: {token}
            }
        }
    })
]
const modules = {
    admin
}
// 输出::状态实例
export const store = new Vuex.Store({ // 状态 实例化
    plugins,
    modules
})

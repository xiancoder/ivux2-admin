import { Api } from '@/api'

export default {
    namespaced: true, // 作用域,配置上以后才能够dispach system/xxx 建议必须 不同的状态里有相同字段值
    state: { // 缓存字段以及默认值
        token: '', // 服务器token 用于存在header中与服务器交换数据使用
        end: 1 // 防呆设计
    },
    getters: {
        access: state => !!state.token // 登录标识 根据token来判断
    },
    mutations: { // 触发事件 注意 vue只有mutations才能触发任意使用状态的代码位置的监听渲染 建议大写
        TOKEN (state, token) { window.localStorage.clear(); state.token = token },
        END: function () {} // 防呆设计
    },
    actions: {
        login ({ commit }, param) { // 广告主登陆
            return new Promise((resolve, reject) => {
                Api.admin.sLogin(param).then(res => {
                    commit('TOKEN', 'YX')
                    commit('USERROLEID', 1)
                    resolve(res)
                }).catch(err => {
                    reject(err)
                })
            })
        }
    }
}

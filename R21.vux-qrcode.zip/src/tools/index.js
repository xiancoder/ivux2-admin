import Vue from 'vue'

/// ////////////////////////////////////////////////////
// 常用的操作封装
/// ////////////////////////////////////////////////////
// 页面信息提示
export const alert = (msg) => {
    Vue.$vux.alert.show({ title: '提示', content: '处理中...' || msg })
}
export const success = (msg) => {
    Vue.$vux.alert.show({ title: '成功提示', content: '操作成功' || msg })
}
export const error = (msg) => {
    Vue.$vux.alert.show({ title: '错误提示', content: '操作失败' || msg })
}

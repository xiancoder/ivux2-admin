<template>
    <router-view></router-view>
</template>
<script>
export default {
    mounted () {
        const phoneHei = document.documentElement.clientHeight || document.body.clientHeight
        const phoneWid = document.documentElement.clientWidth || document.body.clientWidth
        sessionStorage.setItem('phoneHeight', phoneHei) // 手机高度
        sessionStorage.setItem('phoneWidth', phoneWid) // 手机宽度
    }
}
</script>
<style lang="less">
    @import '../styles/main.less';
</style>

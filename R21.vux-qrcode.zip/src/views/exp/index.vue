<template>
    <div>
        <x-header :left-options="{showBack:false}" class="header_white">
            <span class="header_title">经验集V1</span>
        </x-header>
        <div class="header_blank"></div>
        <scroller class="pad15" ref="scroll" lock-x :scroll-bottom-offst="200">
            <div>
                <x-table :cell-bordered="true" :content-bordered="true">
                    <thead>
                        <tr style="background-color: #F7F7F7">
                            <th style="width:70%;text-align: left;">&nbsp;&nbsp;&nbsp;知识标题</th>
                            <th style="text-align: right;">操作&nbsp;&nbsp;&nbsp;</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(row) in response.list" :key="row.id">
                            <td class="tableTL">&nbsp;&nbsp;{{row.fileTitle || '-'}}</td>
                            <td class="tableTR">
                                <span @click="toPage(row.fileRouter)" style="color: #4A8BFF;">前往此页</span>
                                &nbsp;&nbsp;
                            </td>
                        </tr>
                    </tbody>
                </x-table>
            </div>
        </scroller>
    </div>
</template>
<script>
import noData from '@/components/no-data'
import '@/plugins/vux.table'

export default {
    components: {noData},
    data () {
        return {
            pageIndex: 1,
            response: {
                list: [],
                rowcount: null
            }
        }
    },
    methods: {
        toPage (path) {
            this.$router.push({path})
        },
        getList () {
            let data = [
                {fileTitle: '尝试视频组件', fileRouter: '/exp/exp01'},
                {fileTitle: '尝试视频自动播放', fileRouter: '/exp/exp01auto'},
                {fileTitle: '尝试视频横屏', fileRouter: '/exp/exp01heng'},
                {fileTitle: '尝试视频插件', fileRouter: '/exp/exp02'},
                {fileTitle: '表格的优美写法', fileRouter: '/exp/exp03'},
                {fileTitle: '表单的优美写法', fileRouter: '/exp/exp04'},
                {fileTitle: '那个啥', fileRouter: '/exp/exp04'}
            ]
            this.response.list = [...this.response.list, ...data]
            this.response.rowcount = 1
        }
    },
    mounted () {
        this.getList()
    }
}
</script>
<style scoped>
    .tableTL{ text-overflow: ellipsis; white-space: nowrap; text-align: left; }
    .tableTR{ text-overflow: ellipsis; white-space: nowrap; text-align: right; }
    .total{ margin-top: 15px; padding: 0 15px; }
    .vux-table.vux-table-no-content-bordered tr:last-child td:before { border-bottom-width: 0; }
</style>

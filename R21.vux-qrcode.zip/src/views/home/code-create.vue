<template>
    <div>
        <x-header :left-options="{backText: ''}" class="header_white">
            <span class="header_title">生成推广码</span>
        </x-header>
        <div class="header_blank" style="border-bottom: 1px solid #d7d7d7"></div>
        <div class="fix_box">
            <div class="qr_container">
                <qrcode :value="url" type="img" :size="200"></qrcode>
                <div class="title">
                    扫我生成推广码
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import { Qrcode, XHeader } from 'vux'
export default {
    name: 'code-create',
    components: {
        Qrcode, XHeader
    },
    data () {
        return {
            url: 'https://tg.jiake365.com/login'
        }
    }
}
</script>
<style scoped>
    .fix_box{
        position: fixed;
        top: 46px;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #0094eb;
    }
    .qr_container{
        position: relative;
        text-align: center;
        width: 70%;
        border-radius: 10px;
        margin: 25% auto;
        padding: 40px 20px 20px 20px;
        background-color: #ffffff;
    }
    .title{
        font-size: 24px;
        font-weight: bold;
        margin-bottom: 20px;
    }
</style>

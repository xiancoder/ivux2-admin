<template>
   <div>
        <x-header :left-options="{backText: ''}" class="header_white">
            <span class="header_title">上传群码</span>
        </x-header>
        <group :gutter="50">
            <x-input title="群名称" placeholder="请输入群名称" v-model="frm.name"
                text-align="right" :max="20" v-if="!frm.id">
            </x-input>
            <x-number title="人数上限" placeholder="请输入人数上限" v-model="frm.maxCount" text-align="right"
                :fillable="true" :min="0" :max="10000" :step="10" v-if="!frm.id">
            </x-number>
            <cell title="群名称" value="" v-if="!!frm.id">
                <span>{{frm.name||'-'}}</span>
            </cell>
            <cell title="人数上限" value="" v-if="!!frm.id">
                <span>{{frm.maxCount||'0'}}</span>
            </cell>
            <cell title="群二维码" value="">
                <div @click="upImg"
                    style="
                            width: 100px;
                            min-height: 100px;
                            margin-right: 6px;
                            background-image: url(/static/add_img.png);
                            background-size: contain;
                            background-repeat: no-repeat;
                        ">
                    <img :src="frm.qrcodeImgUrl?frm.qrcodeImgUrl:'/static/add_img.png'"
                        style="width:100px;min-height:100px;"/>
                </div>
            </cell>
            <div style="display: none">
                <input ref="uploadImg" type="file" accept="image/*">
            </div>
        </group>
        <box gap="10px 10px">
            <x-button :gradients="['#1D62F0', '#19D5FD']" @click.native="handleSubmit()">提交</x-button>
            <x-button @click.native="handleCancel()">取消</x-button>
        </box>
    </div>
</template>
<script>
import {XHeader, XInput, XNumber, XButton, Box, Group, Cell} from 'vux'

export default {
    components: {
        XHeader, XInput, XNumber, XButton, Box, Group, Cell
    },
    data () {
        return {
            frm: {
                id: 0, // 群id
                name: '', // 群名称
                maxCount: 200, // 最大人数
                qrcodeImgUrl: '', // 群二维码图片地址
                qrcodeImgFile: null // 群二维码文件 for 上传
            }
        }
    },
    methods: {
        upImg () {
            this.$refs.uploadImg.click()
        },
        handleSubmit () {
            if (this.checkFrom()) {
                this.$vux.loading.show({ text: 'Loading' })
                this.submitUploadFile()
            }
        },
        checkFrom () {
            if (!this.frm.id && !this.frm.name) {
                this.$vux.alert.show({ title: '提示', content: '请输入群名称' })
                return false
            }
            if (!this.frm.id && !this.frm.qrcodeImgFile) {
                this.$vux.alert.show({ title: '提示', content: '请选择群二维码' })
                return false
            }
            if (this.frm.id && !this.frm.qrcodeImgFile) {
                this.$vux.alert.show({ title: '提示', content: '请选择新的群二维码' })
                return false
            }
            return true
        },
        submitUploadFile () {
            let fd = new FormData()
            fd.append('image', this.frm.qrcodeImgFile)
            let config = { headers: { 'Content-Type': 'multipart/form-data' }, timeout: 300000 }
            this.$post('api/imgFile/upload', fd, config).then(res => {
                if (res.data.data && res.data.data.res === 1) {
                    this.frm.qrcodeImgUrl = res.data.data.path
                    this.submitJson()
                } else {
                    this.$vux.loading.hide()
                    this.$vux.alert.show({ title: '提示', content: res.data.msg || '上传失败' })
                }
            })
        },
        submitJson () {
            let p = {
                'id': this.frm.id || 0,
                'name': this.frm.name,
                'maxCount': this.frm.maxCount,
                'qrcodeImg': this.frm.qrcodeImgUrl
            }
            this.$post('api/qun/create', p).then((res) => {
                this.$vux.loading.hide()
                if (res.data.data && res.data.data.res === 1) {
                    this.$vux.alert.show({title: '提示', content: '保存成功'})
                    this.$router.replace({name: 'home-realTimeQun'})
                } else {
                    this.$vux.alert.show({title: '提示', content: res.data.msg || '保存失败'})
                }
            })
        },
        handleCancel () {
            this.$router.replace({name: 'home-realTimeQun'})
        }
    },
    mounted () {
        const self = this
        this.$refs.uploadImg.onchange = function () {
            if (this.files[0]) {
                self.$vux.loading.show({ text: 'Loading' })
                self.frm.qrcodeImgFile = this.files[0]
                const reads = function (file) {
                    var reader = new FileReader()
                    reader.onload = function (e) {
                        self.frm.qrcodeImgUrl = e.target.result
                        self.$vux.loading.hide()
                    }
                    reader.readAsDataURL(file)
                }
                reads(this.files[0])
            }
        }
        if (this.$route.query.id) {
            this.frm.id = this.$route.query.id
            this.$get('api/qun/getInfo', {id: this.frm.id}).then((res) => {
                this.$vux.loading.hide()
                let r = res.data.data.info
                if (r.id) {
                    this.frm.name = r.name
                    this.frm.maxCount = r.maxCount
                    this.frm.qrcodeImgUrl = r.qrcodeImg
                }
            })
        }
    }
}
</script>
<style scoped>
</style>

<template>
   <div>首页</div>
</template>
<script>
export default {
    name: 'home'
    components: {
    },
    data() {
        return {
        }
    },
    methods: {
    },
    mounted () {
    }
}
</script>
<style scoped>
</style>

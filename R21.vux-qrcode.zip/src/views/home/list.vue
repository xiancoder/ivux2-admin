<template>
    <div>
        <x-header :left-options="{showBack: false}" class="header_white">
            <span class="header_title">数据查询</span>
        </x-header>
        <div class="header_blank" style="border-bottom: 1px solid #d7d7d7"></div>
        <img src="../../img/write.png" class="search" @click="showPop = true" v-if="!showPop">
        <popup v-model="showPop" position="top">
            <group :gutter="50">
                <popup-picker show-name :columns="1" title="群名" :data="typeList" v-model="type" ></popup-picker>
                <datetime v-model="begin" title="开始日期" year-row="{value}年" month-row="{value}月" day-row="{value}日"></datetime>
                <datetime v-model="end" title="结束日期" year-row="{value}年" month-row="{value}月" day-row="{value}日"></datetime>
                <x-input title="推广员" placeholder="请输入推广员" v-model="fromUser" text-align="right" :max="20"></x-input>
                <div class="check_icon"><check-icon :value.sync="unlimited">无限级</check-icon></div>
                <x-input title="群众" placeholder="请输入群众" v-model="toUser" text-align="right" :max="20"></x-input>
            </group>
            <div class="logout" @click="searchContact">查询</div>
        </popup>
        <div class="total" v-if="contactList.length > 0">共 {{listCount}} 条</div>
        <scroller lock-x  @on-scroll-bottom="onScrollBottom" ref="scrollerBottom" :scroll-bottom-offst="100" height="-137">
            <div style="padding: 15px">
                <div class="no_follow" v-show="contactList.length === 0">
                    暂无数据
                </div>
                <div class="contact_modal" v-for="(contact,index) in contactList" :key="index">
                    <div class="contact_msg">
                        <div class="contact_mark">
                            {{contact.crowdname}}
                            <div class="contact_cpy">{{contact.createdTime}}</div>
                        </div>
                        <div class="contact_mark">
                            {{contact.nickname}}
                            <span style="color: #0094eb">{{sexBox[contact.sex]}}</span>
                            <div class="contact_cpy">上级：{{contact.upname || '无'}}</div>
                        </div>
                    </div>
                </div>
            </div>
            <load-more v-show="loading" tip="loading"></load-more>
            <divider v-show="noMore && contactList.length > 0">没有更多数据</divider>
        </scroller>
        <menu-bottom :select="2"></menu-bottom>
    </div>
</template>
<script>
import {XHeader, XInput, Group, Cell, Scroller, LoadMore, Divider, PopupPicker, Datetime, CheckIcon, Popup} from 'vux'
import { dateFormat } from '../../utils/date'
import menuBottom from '@/components/menu-bottom.vue'

export default {
    name: 'list',
    components: {
        XHeader, XInput, Group, Cell, Scroller, LoadMore, Divider,
        PopupPicker, Datetime, CheckIcon, Popup, menuBottom
    },
    data () {
        return {
            showPop: false,
            type: ['0'],
            typeList: [],
            begin: dateFormat(new Date()),
            end: dateFormat(new Date()),
            fromUser: '',
            unlimited: false,
            toUser: '',
            currentCount: 30,
            listCount: 1,
            loading: false,
            noMore: false,
            contactList: [],
            sexBox: ['未知', '男', '女']
        }
    },
    methods: {
        init () {
            this.$get('api/system/getcrowds', {
            }).then((res) => {
                const list = res.data.data.list
                let box = [{name: '全部群', value: '0'}]
                for (let i = 0; i < list.length; i++) {
                    box.push({
                        name: list[i].name,
                        value: list[i].value.toString()
                    })
                }
                this.typeList = box
            })
            this.getList()
        },
        getList () {
            this.$get('api/users/get', {
                tgid: 1,
                crowdid: parseInt(this.type[0]) === 0 ? null : parseInt(this.type[0]),
                begin: this.begin,
                end: this.end,
                fromUser: this.fromUser,
                unlimited: this.unlimited,
                toUser: this.toUser,
                pageIndex: 1,
                pageSize: 15
            }).then((res) => {
                this.contactList = res.data.list
                this.listCount = res.data.rowcount
                if (this.listCount <= 15) {
                    this.noMore = true
                }
                this.loading = false
            })
        },
        searchContact () {
            if (new Date(this.begin).getTime() > new Date(this.end).getTime()) {
                this.$vux.toast.show({ type: 'cancel', text: '开始日期需早于结束日期' })
                return
            }
            this.currentCount = 30
            this.noMore = false
            this.loading = true
            this.getList()
            this.showPop = false
            this.$nextTick(() => {
                this.$refs.scrollerBottom.reset({top: 0})
            })
        },
        onScrollBottom () {
            if (!this.loading && this.contactList.length !== 0 && !this.noMore) {
                this.loading = true
                setTimeout(() => {
                    this.$get('api/users/get', {
                        tgid: parseInt(this.type[0]),
                        begin: this.begin,
                        end: this.end,
                        fromUser: this.fromUser,
                        unlimited: this.unlimited,
                        toUser: this.toUser,
                        pageIndex: 1,
                        pageSize: 15
                    }).then((res) => {
                        this.contactList = res.data.list
                        if (this.currentCount < res.data.rowCount) {
                            this.currentCount = this.currentCount + 15
                        } else {
                            this.noMore = true
                        }
                        this.listCount = res.data.rowcount
                        this.loading = false
                    })
                }, 1000)
            }
        }
    },
    mounted () {
        this.init()
    }
}
</script>
<style scoped>
    .search{
        position: fixed;
        width: 50px;
        height: 50px;
        right: 15px;
        bottom: 75px;
        z-index: 9999;
    }
    .logout{
        width: 70%;
        margin: 13px auto;
        line-height: 40px;
        border-radius: 20px;
        background-color: #4a8bff;
        color:#fff;
        border: 1px solid #e7e7e7;
        text-align: center;
    }
    .check_icon{
        margin-left: 15px;
        padding-right: 15px;
        padding-bottom: 10px;
        text-align: right;
        border-bottom: 1px solid #eee;
    }
    .total{
        margin-top: 15px;
        padding: 0 15px;
    }
</style>

<template>
    <div>
        <x-header :left-options="{showBack:false,preventGoBack:true}" class="header_white">
            <span slot="left" style="color:#fff;" @click="toCode">生成推广码</span>
            <span class="header_title" @click="toTest">基础数据</span>
            <span slot="right" style="color:#fff;" @click="toAddQun(0)">添加推广群</span>
        </x-header>
        <div class="header_blank" style="border-bottom: 1px solid #d7d7d7"></div>
        <div class="total">
            共计创建{{groupTotal}}个群，已满 {{fullTotal}}个群，
            <br>
            群总人数{{userTotal}}
        </div>
        <tab :select="1" :names="names"></tab>
        <load-more v-show="firstload" tip="loading"></load-more>
        <no-data v-if="response.list.length===0 && !firstload"></no-data>
        <scroller v-show="response.list.length>0" class="pad15" ref="scroll" lock-x :scroll-bottom-offst="200" @on-scroll-bottom="loadData()">
            <div>
                <x-table :cell-bordered="false" :content-bordered="false">
                    <thead>
                        <tr style="background-color: #F7F7F7">
                            <th style="width:150px;text-align: left;">&nbsp;&nbsp;群名称</th>
                            <th>人数</th>
                            <th>剩余(天)</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(row, index) in response.list" :key="row.id">
                            <td class="nameDiv">&nbsp;&nbsp;{{row.crowdName || '-'}}</td>
                            <td>{{row.online}}/{{row.crowdCount}}</td>
                            <td>{{row.overDay}}</td>
                            <td>
                                <span @click="toAddQun(row.id)" style="color: #4A8BFF;">编辑</span>
                                <span @click="del(index, row.id)" style="color: #4A8BFF;" v-show="index !==0">删除</span>
                            </td>
                        </tr>
                    </tbody>
                </x-table>
                <load-more v-show="loading" tip="loading"></load-more>
                <divider v-show="noMore && response.list.length>0">没有更多数据</divider>
            </div>
        </scroller>
        <menu-bottom :select="1"></menu-bottom>
    </div>
</template>
<script>
import tab from '@/components/tab'
import noData from '@/components/no-data'
import menuBottom from '@/components/menu-bottom.vue'
import {XHeader, XTable, Scroller, LoadMore, Divider} from 'vux'

export default {
    components: {
        tab, XHeader, XTable, Scroller, noData, LoadMore, menuBottom, Divider
    },
    data () {
        return {
            groupTotal: 0, // 总群数
            fullTotal: 0, // 已满群数
            userTotal: 0, // 群总人数
            names: [
                {name: '实时群', path: '/realTimeQun'},
                {name: '已满群', path: '/gratifiedQun'}
            ],
            pageIndex: 1,
            response: {
                list: [],
                rowcount: null
            },
            first: 1, // 是否首次加载
            firstload: true, // 首次加载loading
            loading: false,
            noMore: false,
            loadOne: 0 // 解决下拉触发多次
        }
    },
    methods: {
        getList () {
            this.$api.qun.realtimeList(this.pageIndex).then(info => {
                this.first++
                if (this.first === 2) { this.firstload = false }
                let data = info.list || []
                this.response.list = [...this.response.list, ...data]
                this.response.rowcount = info.rowcount
                this.loading = false
                if (this.pageIndex * 15 >= this.response.rowcount) {
                    this.loadOne = 1
                    this.noMore = true
                }
                this.$nextTick(() => {
                    if (this.pageIndex > 1) {
                        this.$refs.scroll.reset()
                    }
                })
            })
        },
        // 下拉刷新
        loadData () {
            if (++this.loadOne === 1) {
                this.loading = true
                this.pageIndex++
                this.getList()
            }
        },
        // 删除
        del (index, id) {
            const that = this
            this.$vux.confirm.show({
                content: '<strong>确定要删除该群吗？</strong>',
                onConfirm () {
                    this.$api.qun.del(id).then(() => {
                        that.response.list.splice(index, 1)
                    })
                }
            })
        },
        toAddQun (val) {
            if (val === 0) {
                this.$router.push({path: '/editQun'})
            } else {
                this.$router.push({path: '/editQun', query: {id: val}})
            }
        },
        toCode () {
            this.$router.push({name: 'login'})
        },
        toTest () {
            this.$router.push({name: 'test'})
        }
    },
    mounted () {
        this.$api.qun.totalInfo().then(info => {
            this.groupTotal = info.groupTotal
            this.fullTotal = info.fullTotal
            this.userTotal = info.userTotal
        })
        this.getList()
        this.$refs.scroll.styles.height = sessionStorage.getItem('phoneHeight') * 1 - 187 + 'px'
    }
}
</script>
<style scoped>
    .nameDiv{ width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; display: inline-block; text-align: left; padding-left: 4px; }
    .total{ margin-top: 15px; padding: 0 15px; }
    .vux-table.vux-table-no-content-bordered tr:last-child td:before { border-bottom-width: 0; }
</style>

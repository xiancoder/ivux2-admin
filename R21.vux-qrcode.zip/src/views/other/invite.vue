<template>
    <div>
        <div v-show="showPage">
            <div class="tc" v-if="isRecord === 0">
               <img :src="path" @touchstart="gotouchstart" style="width: 100%;display: block">
            </div>
            <div v-if="isRecord === 1" class="intro">
                <!--<img src="../../img/0.jpg" style="width: 100%;display: block">-->
                您已加入过该群
            </div>
            <div class="logout" @click="toShare(0)">点击分享</div>
            <div class="btn_intro" v-if="isRecord === 1">点击分享生成推广码进行分享</div>
        </div>
    </div>
</template>
<script>
export default {
    data () {
        return {
            showPage: true,
            isRecord: 0, // 是否已进群
            tgid: '1',
            code: this.$route.query.code,
            openId: '', // 用户openId
            img: '', // 用户头像
            userName: '', // 用户名称
            timeOutEvent: 0,
            crowdId: 0, // 群id
            name: '', // 群名称
            path: '' // 群码
        }
    },
    methods: {
        getType (url) {
            let index = url.lastIndexOf('_')
            url = url.substring(index + 1, url.length)
            return url
        },
        getId (url) {
            let index = url.lastIndexOf('_')
            url = url.substring(0, index)
            return url
        },
        gotouchstart () {
            let self = this
            clearTimeout(this.timeOutEvent) // 清除定时器
            this.timeOutEvent = 0
            this.timeOutEvent = setTimeout(function () {
                // alert('长按了')
                self.saveId()
            }, 450) // 这里设置定时
        },
        // 手释放，如果在500毫秒内就释放，则取消长按事件，此时可以执行onclick应该执行的事件
        gotouchend () {
            clearTimeout(this.timeOutEvent)
            if (this.timeOutEvent !== 0) {
                // alert('点击了')
                // 这里写要执行的内容（尤如onclick事件）
            }
        },
        // 如果手指有移动，则取消所有事件，此时说明用户只是要移动而不是长按
        gotouchmove () {
            clearTimeout(this.timeOutEvent) // 清除定时器
            this.timeOutEvent = 0
            // alert('移动了')
        },
        toShare (n) {
            this.$router.push({name: 'share', query: {begin: this.openId, img: this.img, name: this.userName, type: this.tgid, origin: n}})
        },
        saveId () {
            this.$get('api/userinfo/second', {
                id: this.getId(this.$route.query.state),
                openid: this.openId,
                tgid: this.tgid,
                crowdid: this.crowdId
            }).then((res) => {
                if (!this.showPage) {
                    this.$vux.loading.hide()
                    this.toShare('1')
                }
            })
        }
    },
    mounted () {
        if (this.getId(this.$route.query.state) === '') {
            this.showPage = false;
            this.$vux.loading.show({
                text: '生成中'
            })
        }
        this.tgid = this.getType(this.$route.query.state)
        this.$get('api/userinfo/get', {
            id: this.getId(this.$route.query.state),
            tgid: this.tgid,
            code: this.$route.query.code
        }).then((res) => {
            if (res) {
                this.openId = res.data.aa.openid
                this.img = res.data.aa.headimgurl
                this.userName = res.data.aa.nickname
                this.isRecord = res.data.isRecord
                this.crowdId = res.data.crowd.crowdid
                this.name = res.data.crowd.name
                this.path = res.data.crowd.path
                if (!this.showPage) {
                    this.saveId();
                }
            } else {
                alert('无返回值')
            }
        })
    }
}
</script>
<style scoped>
    .logout{
        width: 70%;
        margin: 13px auto;
        line-height: 40px;
        border-radius: 20px;
        background-color: #4a8bff;
        color:#fff;
        border: 1px solid #e7e7e7;
        text-align: center;
    }
    .intro{
        text-align: center;
        font-size: 26px;
        margin: 30% 0;
        color: #ff5500;
    }
    .btn_intro{
        text-align: center;
        display: block;
        font-size: 14px;
        color: #666;
    }
</style>

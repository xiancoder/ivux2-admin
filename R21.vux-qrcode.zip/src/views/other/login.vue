<template>
    <div> </div>
</template>
<script>
export default {
    mounted () {
        // let state = 'oHxnJwkVGJSMZDcPam3o0DYcODJ4_1'; // 初始分享人openId
        let state = '_1' // 初始分享人openId
        if (this.$route.query.begin) {
            state = this.$route.query.begin + '_' + this.$route.query.tgid
        } // 次级分享人openId
        const appid = 'wxe07f535d7bd665ca'
        location.href = 'https://open.weixin.qq.com/connect/oauth2/authorize' +
            '?appid=' + appid +
            '&redirect_uri=' + 'https%3a%2f%2ftg.jiake365.com%2frecall' +
            '&response_type=code' +
            '&scope=snsapi_userinfo' +
            '&state=' + state +
            '#wechat_redirec'
    }
}
</script>
<style scoped>
</style>

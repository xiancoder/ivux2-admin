<template>
    <div>
        <x-header v-if="origin" @on-click-back="goHome" :left-options="{backText: '',preventGoBack: true}" class="header_white">
            <span class="header_title">{{name}}的推广码</span>
        </x-header>
        <div class="header_blank" v-if="origin"></div>
        <div class="user_name" v-if="!origin">{{name}}的推广码</div>
        <div class="fix_box" ref="box" v-if="!src">
            <div class="qr_container">
                <img :src="img" class="user_img"/>
                <div class="title">
                    欢迎加入月野兔大家庭<br>
                    扫码即可联系小助手
                </div>
                <qrcode :value="url" type="canvas"></qrcode>
            </div>
        </div>
        <div v-if="src">
            <img :src="src" style="width: 100%"/>
        </div>
        <div class="download_btn" v-if="src">
            长按保存
        </div>
        <div class="download_btn" @click="goAnywhere">
            跳转
        </div>
    </div>
</template>
<script>
import {Qrcode, XHeader} from 'vux'
import html2canvas from 'html2canvas'
export default {
    components: {
        Qrcode, XHeader
    },
    data () {
        return {
            origin: this.$route.query.origin,
            tgid: this.$route.query.type,
            img: this.$route.query.img,
            name: this.$route.query.name,
            url: 'https://tg.jiake365.com/login?begin=' + this.$route.query.begin + '&tgid=' + this.$route.query.type,
            src: ''
        }
    },
    methods: {
        init () {
            const self = this
            setTimeout(() => {
                html2canvas(self.$refs.box).then(function (canvas) {
                    self.src = canvas.toDataURL()
                })
            }, 1500)
        },
        goHome () {
            this.$router.push({name: 'home-realTimeQun'})
        },
        goAnywhere () {
            this.$router.push({name: 'home-realTimeQun'})
        }
    },
    mounted () {
        this.init()
    },
    beforeRouteEnter (to, from, next) {
        console.log('我进来了')
        next() // 必须
    },
    beforeRouteLeave (to, from, next) {
        console.log('我出去了')
        next() // 必须
    }
}
</script>
<style lang='less'>
    @import '~@/styles/main.less';
</style>
<style scoped>
    .user_name{ line-height: 50px; text-align: center; font-size: 16px; }
    .fix_box{ padding: 20% 0; background-color: #0094eb; }
    .qr_container{ position: relative; text-align: center; width: 75%; border-radius: 10px; margin: 0 auto; padding: 50px 20px 40px 30px; background-color: #ffffff; }
    .user_img{ position: absolute; top: -35px; left: 50%; width: 70px; height: 70px; border-radius: 35px; margin-left: -35px; }
    .title{ font-size: 24px; font-weight: bold; margin-bottom: 20px; }
    .download_btn{ font-size: 16px; font-weight: bold; width: 70%; margin: 20px auto; line-height: 40px; text-align: center; }
    @media screen and (max-width: 375px) {
        .fix_box { padding: 20% 0; }
        .download_btn{ margin: 20px auto; }
    }
    @media screen and (max-width: 320px) {
        .fix_box { padding: 15% 0; }
        .download_btn{ margin: 11px auto; }
    }
</style>

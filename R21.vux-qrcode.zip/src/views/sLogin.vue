<template>
    <div>
        <!-- <x-header :left-options="{showBack: false}" class="header_white">
            <span class="header_title">用户登录</span>
        </x-header> -->
        <div class="login_container">
            <div class="login_logo">
                <div class="login_logo_box"><img src="/static/logo.png"/></div>
                加客宝
            </div>
            <div v-show="checkError" class="login_showError">
                {{['登录失败','qq未绑定','非法请求','用户名或密码错误'][checkError]}}
            </div>
            <group class="user_name" :class="{'input_active':userInputClass}">
                <x-input v-model="frm.userName" type="text" placeholder="用户名"
                    @on-focus="userInputClass=true;" @on-blur="userInputClass=false">
                    <i slot="label" class="fa fa-user input_icon" :class="{'input_focus':userInputClass}"></i>
                </x-input>
            </group>
            <group class="user_password" :class="{'input_active':passwordInputClass}">
                <x-input v-model="frm.password" type="password"
                    onpaste="return false" placeholder="登录密码"
                    @on-focus="passwordInputClass=true;" @on-blur="passwordInputClass=false">
                    <i slot="label" class="fa fa-lock input_icon" :class="{'input_focus':passwordInputClass}"></i>
                </x-input>
            </group>
            <x-button class="login_button" @click.native="userLogin">登 录</x-button>
            <div class="other_login">
                <!--其他方式登录-->
                <a href="url">
                    <img src="/static/qq_active.png"/>
                </a>
            </div>
            <div style="height:40px"></div>
        </div>
    </div>
</template>
<script>
import '@/plugins/vux.from'

export default {
    data () {
        return {
            checkError: '', // 登录后的报错信息
            userInputClass: '', // 用户名输入框的样式控制
            passwordInputClass: '', // 密码输入框的样式控制
            storeName: false, // 是否保存用户名
            frm: {
                userName: '123', // 用户名
                password: '123abc123' // 密码
            }
        }
    },
    methods: {
        userLogin () {
            this.$post('api/system/staff_login', {
                userName: this.frm.userName,
                pwd: this.frm.password
            }).then((res) => {
                if (res.data.data.res !== 1) {
                    this.checkError = '3'
                    return
                }
                window.localStorage.setItem('imlogined', 1)
                this.$router.push({ name: 'exp-list' })
            })
        },
        focusInput () {
            setTimeout(function () {
                document.body.scrollTop = document.body.scrollHeight
            }, 100)
        }
    },
    mounted () {
        this.checkError = window.location.href.substr(-1)
        window.addEventListener('resize', function () {
            if (
                document.activeElement.tagName === 'INPUT' ||
                document.activeElement.tagName === 'TEXTAREA' ||
                document.activeElement.getAttribute('contenteditable') === 'true'
            ) {
                window.setTimeout(function () {
                    if ('scrollIntoView' in document.activeElement) {
                        document.activeElement.scrollIntoView();
                    } else {
                        document.activeElement.scrollIntoViewIfNeeded();
                    }
                }, 0);
            }
        });
    }
}
</script>
<style lang="less" scoped>
.login_container{
    padding: 0 15%; text-align: center;
    .login_logo{
        padding: 60px 0 20px 0; font-size: 18px; color: #9A9A9A;
        .login_logo_box{
            margin-bottom: 10px;height:100px;
            img{ width: 30%; }
        }
    }
    .login_showError{color: red;font-size: 12px;text-align: left;padding: 0 10px;}
    .user_name .weui-cells{
        margin-top: 0;
        &:before{ border: none; }
    }
    .user_password .weui-cells{
        &:before{ border: none; }
    }
    .input_active .weui-cells:after{ border-color: #2599e4; }
    .input_focus{ color: #2599e4; }
    .input_icon{ font-size: 14px;margin-right: 10px; }
    .login_button{ margin-top: 30px; background-color: #0094eb; line-height: 36px; border-radius: 18px; color: #ffffff; }
    .other_login{
        font-size: 13px; color: #9A9A9A; margin-top: 30px;
        a{display: inline-block;height: 55px;}
        img{ width: 50px; }
    }
}
</style>

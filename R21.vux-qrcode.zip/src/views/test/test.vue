<template>
    <div>
        <div style="padding: 15px">
            【京东自营】京东京造 保鲜袋组合装9包装 （大号+中号+小号）*3  一次性抽取式保鲜食品袋<br>
            ---------------------------<br>
            京东价：￥42.90<br>
            券后价：￥37.90<br>
            抢购链接：<a href="https://u.jd.com/WH2rDt">https://u.jd.com/WH2rDt</a>
        </div>
        <div>
            <img src="../../img/test.jpg" style="width: 100%">
        </div>
    </div>
</template>
<script>
export default {
}
</script>
<style scoped>
</style>
